export class Triangle {
  constructor() {
    this.type = "triangle";
    this.position = [0.0, 0.0, 0.0];
    this.color = [1.0, 1.0, 1.0, 1.0];
    this.size = 5.0;
  }
  
  render() {
    var xy = this.position;
    var rgba = this.color;
    var size = this.size;

    // Pass the color of a point to u_FragColor variable
    gl.uniform4f(u_FragColor, rgba[0], rgba[1], rgba[2], rgba[3]);
    // Pass the size of a point to u_PointSize variable
    gl.uniform1f(u_PointSize, size);
    // Draw
    var d = this.size / 200.0; //delta
    var h = d * (Math.sqrt(3) / 2);
    drawTriangle([
      xy[0] - d / 2, xy[1] - h / 3,
      xy[0] + d / 2, xy[1] - h / 3,
      xy[0], xy[1] + 2 * h / 3
    ]);
  }
}

export function drawTriangle(vertices) {
  var n = 3;
  
  // Create buffer object
  var vertexBuffer = gl.createBuffer();
  if (!vertexBuffer) {
    console.log('Failed to create the buffer object');
    return;
  }

  // Bind the buffer object to target
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  // Write date into the buffer object
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.DYNAMIC_DRAW);
  // Assign the buffer object to a_Position variable
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(a_Position);
  
  // Draw
  gl.drawArrays(gl.TRIANGLES, 0, n);
}